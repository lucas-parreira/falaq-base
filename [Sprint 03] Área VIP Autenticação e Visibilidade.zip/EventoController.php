<?php

namespace App\Http\Controllers;

use App\Models\Evento;
use App\Models\Pergunta;
use Illuminate\Http\Request;

class EventoController extends Controller
{
    /**
     * Lista os eventos publicados. Rascunhos ficam ocultos da home.
     */
    public function index()
    {
        $eventos = Evento::where('rascunho', false)
            ->latest()
            ->paginate(10);

        return view('eventos.index', compact('eventos'));
    }

    /**
     * Formulário de criação de evento (apenas Organizadores logados).
     */
    public function create()
    {
        return view('eventos.create');
    }

    /**
     * Armazena um novo evento.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'titulo' => ['required', 'string', 'max:255'],
            'descricao' => ['nullable', 'string'],
        ]);

        $evento = Evento::create([
            ...$validated,
            'user_id' => auth()->id(),
        ]);

        return redirect()
            ->route('eventos.show', $evento)
            ->with('success', 'Evento criado com sucesso!');
    }

    /**
     * Exibe um evento e o mural de perguntas aprovadas.
     *
     * Ticket #002 (Sprint 01): filtro por evento + ordenação decrescente + paginação de 10.
     * Ticket #004 (Sprint 02): with('user') encadeado ANTES do paginate, elimina o N+1.
     * Ticket #006 (Sprint 03): where('is_public', true) esconde perguntas pendentes.
     */
    public function show(Evento $evento)
    {
        $perguntas = Pergunta::with('user')
            ->where('evento_id', $evento->id)
            ->where('is_public', true)
            ->latest()
            ->paginate(10);

        return view('eventos.show', compact('evento', 'perguntas'));
    }

    /**
     * Formulário de edição de evento.
     */
    public function edit(Evento $evento)
    {
        return view('eventos.edit', compact('evento'));
    }

    /**
     * Atualiza um evento existente.
     */
    public function update(Request $request, Evento $evento)
    {
        $validated = $request->validate([
            'titulo' => ['required', 'string', 'max:255'],
            'descricao' => ['nullable', 'string'],
        ]);

        $evento->update($validated);

        return redirect()
            ->route('eventos.show', $evento)
            ->with('success', 'Evento atualizado com sucesso!');
    }

    /**
     * Remove um evento.
     */
    public function destroy(Evento $evento)
    {
        $evento->delete();

        return redirect()
            ->route('eventos.index')
            ->with('success', 'Evento removido com sucesso!');
    }
}

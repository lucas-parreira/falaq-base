<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePerguntaRequest;
use App\Models\Evento;
use App\Models\Pergunta;

class PerguntaController extends Controller
{
    /**
     * Armazena uma nova pergunta enviada por um usuário autenticado.
     *
     * Ticket #001 (Sprint 01): validação via StorePerguntaRequest.
     * Ticket #005 (Sprint 03): rota protegida por middleware auth (ver routes/web.php).
     * Ticket #006 (Sprint 03): pergunta nasce com is_public = false (pendente de moderação).
     */
    public function store(StorePerguntaRequest $request, Evento $evento)
    {
        Pergunta::create([
            'texto' => $request->validated('texto'),
            'evento_id' => $evento->id,
            'user_id' => auth()->id(),
            'is_public' => false,
        ]);

        return redirect()
            ->route('eventos.show', $evento)
            ->with('success', 'Pergunta enviada! Ela aparecerá após aprovação do organizador.');
    }
}

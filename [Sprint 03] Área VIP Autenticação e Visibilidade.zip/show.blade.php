@extends('layouts.app')

@section('title', $evento->titulo)

@section('content')
<div class="container">

    <div class="mb-4">
        <h1 class="h3 mb-1">{{ $evento->titulo }}</h1>
        @if (!empty($evento->descricao))
            <p class="text-muted mb-0">{{ $evento->descricao }}</p>
        @endif
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h2 class="h5 mb-3">Envie sua pergunta</h2>

            @auth
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $erro)
                                <li>{{ $erro }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                @if (session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif

                <form action="{{ route('perguntas.store', $evento) }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <textarea
                            name="texto"
                            class="form-control @error('texto') is-invalid @enderror"
                            rows="3"
                            placeholder="Escreva sua pergunta (mínimo 10 caracteres)">{{ old('texto') }}</textarea>
                        @error('texto')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <button type="submit" class="btn btn-primary">Enviar pergunta</button>
                </form>
            @else
                <p class="text-muted mb-0">
                    <a href="{{ route('login') }}">Faça login</a> para enviar uma pergunta.
                </p>
            @endauth
        </div>
    </div>

    <h2 class="h5 mb-3">Perguntas ({{ $perguntas->total() }})</h2>

    @forelse ($perguntas as $pergunta)
        <div class="card mb-3">
            <div class="card-body">
                <p class="card-text">{{ $pergunta->texto }}</p>

                {{-- Ticket #003: nome do autor com fallback seguro contra nulos --}}
                <small class="text-muted">
                    Enviado por: <strong>{{ $pergunta->user->name ?? 'Anônimo' }}</strong>
                    &middot; {{ $pergunta->created_at->diffForHumans() }}
                </small>
            </div>
        </div>
    @empty
        <div class="alert alert-info">
            Ainda não há perguntas aprovadas para este evento.
        </div>
    @endforelse

    {{ $perguntas->links() }}

</div>
@endsection

<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StorePerguntaRequest extends FormRequest
{
    public function authorize(): bool
    {
        // Ticket #005 (Sprint 03): a própria rota já exige auth,
        // mas mantemos true aqui pois a autorização de acesso é feita pelo middleware.
        return true;
    }

    public function rules(): array
    {
        return [
            'texto' => ['required', 'string', 'min:10', 'max:255'],
            'evento_id' => ['required', 'exists:eventos,id'],
        ];
    }
}

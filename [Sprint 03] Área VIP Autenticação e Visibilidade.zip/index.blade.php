@extends('layouts.app')

@section('title', 'Eventos')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Eventos</h1>
        @auth
            <a href="{{ route('eventos.create') }}" class="btn btn-primary">Criar evento</a>
        @endauth
    </div>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @forelse ($eventos as $evento)
        <div class="card mb-3">
            <div class="card-body">
                <h2 class="h5">
                    <a href="{{ route('eventos.show', $evento) }}" class="text-decoration-none">
                        {{ $evento->titulo }}
                    </a>
                </h2>
                @if (!empty($evento->descricao))
                    <p class="text-muted mb-0">{{ $evento->descricao }}</p>
                @endif
            </div>
        </div>
    @empty
        <div class="alert alert-info">Nenhum evento publicado ainda.</div>
    @endforelse

    {{ $eventos->links() }}
</div>
@endsection

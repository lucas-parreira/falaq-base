<?php

use App\Http\Controllers\EventoController;
use App\Http\Controllers\PerguntaController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', [EventoController::class, 'index'])->name('home');

// ---------------------------------------------------------------------
// Autenticação (Login / Registro) - geradas pelo Laravel Breeze
// ---------------------------------------------------------------------
require __DIR__.'/auth.php';

// ---------------------------------------------------------------------
// Perfil do usuário logado (vem do Breeze)
// ---------------------------------------------------------------------
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// ---------------------------------------------------------------------
// Eventos
// ---------------------------------------------------------------------
Route::get('/eventos', [EventoController::class, 'index'])->name('eventos.index');
Route::get('/eventos/{evento}', [EventoController::class, 'show'])->name('eventos.show');

// Apenas Organizadores logados podem criar/gerenciar eventos
Route::middleware('auth')->group(function () {
    Route::get('/eventos/criar', [EventoController::class, 'create'])->name('eventos.create');
    Route::post('/eventos', [EventoController::class, 'store'])->name('eventos.store');
    Route::get('/eventos/{evento}/editar', [EventoController::class, 'edit'])->name('eventos.edit');
    Route::put('/eventos/{evento}', [EventoController::class, 'update'])->name('eventos.update');
    Route::delete('/eventos/{evento}', [EventoController::class, 'destroy'])->name('eventos.destroy');
});

// ---------------------------------------------------------------------
// Perguntas
// ---------------------------------------------------------------------
// Ticket #005 (Sprint 03): só usuários autenticados podem postar perguntas.
// Anônimo tentando acessar é redirecionado para /login (HTTP 302).
Route::post('/eventos/{evento}/perguntas', [PerguntaController::class, 'store'])
    ->name('perguntas.store')
    ->middleware('auth');

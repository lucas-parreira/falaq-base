<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FalaQ - @yield('title', 'Perguntas ao vivo')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="{{ route('eventos.index') }}">FalaQ</a>
            <div class="ms-auto">
                @auth
                    <span class="text-light me-3">Olá, {{ auth()->user()->name }}</span>
                    <form action="{{ route('logout') }}" method="POST" class="d-inline">
                        @csrf
                        <button class="btn btn-outline-light btn-sm" type="submit">Sair</button>
                    </form>
                @else
                    <a href="{{ route('login') }}" class="btn btn-outline-light btn-sm me-2">Entrar</a>
                    <a href="{{ route('register') }}" class="btn btn-light btn-sm">Registrar</a>
                @endauth
            </div>
        </div>
    </nav>

    <main>
        @yield('content')
    </main>
</body>
</html>
